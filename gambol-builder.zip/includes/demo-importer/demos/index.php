<?php
/**
 * Silence is golden.
 *
 * @package GambolBuilder
 */
